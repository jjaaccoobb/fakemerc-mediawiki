OOJSPlus.ui.api.UserStore = function () {};

OO.initClass( OOJSPlus.ui.api.UserStore );

OOJSPlus.ui.api.UserStore.prototype.getUsers = function () {

};


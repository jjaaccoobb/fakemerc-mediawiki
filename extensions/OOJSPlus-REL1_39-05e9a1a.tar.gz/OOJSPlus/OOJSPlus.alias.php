<?php

$specialPageAliases = [];

/** English (English) */
$specialPageAliases['en'] = [
	'OOJSPlusDemos' => [ 'OOJSPlusDemos', 'OOJSPlus Demos', 'OOJSPlus demos' ],
];
